Fort Boyard by Little-Goomba
https://3dwarehouse.sketchup.com/model/930c70737fdf4dcab21867f2197bb3a/Fort-Boyard