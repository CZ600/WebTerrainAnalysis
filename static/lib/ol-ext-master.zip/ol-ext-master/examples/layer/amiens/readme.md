Château de la Borie by Keshan P.
https://3dwarehouse.sketchup.com/model/5dde16edfa2190ff6873eb93dc851a9b/Ch%C3%A2teau-de-la-Borie