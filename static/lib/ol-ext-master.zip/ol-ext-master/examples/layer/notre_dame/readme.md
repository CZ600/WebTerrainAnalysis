Notre Dame by Pierro11
https://b2b.partcommunity.com/community/knowledge/en/detail/3047/Notre-Dame+de+Paris