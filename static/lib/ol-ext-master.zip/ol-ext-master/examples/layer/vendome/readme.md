La Colonne Vendôme by Little-Goomba
https://3dwarehouse.sketchup.com/model/d392623538ef816dd36463683ffa2e41/La-Colonne-Vend%C3%B4me