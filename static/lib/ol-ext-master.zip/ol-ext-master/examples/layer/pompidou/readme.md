Le Centre Pompidou by Little-Goomba
https://3dwarehouse.sketchup.com/model/2ad9223779babdb8c9646200c38fe4c0/Le-Centre-Pompidou