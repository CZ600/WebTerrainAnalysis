Château de Bussy-Rabutin by Keshan P.
https://3dwarehouse.sketchup.com/model/4c05c577bc382b6bcb329424aa12d9a2/Ch%C3%A2teau-de-Bussy-Rabutin