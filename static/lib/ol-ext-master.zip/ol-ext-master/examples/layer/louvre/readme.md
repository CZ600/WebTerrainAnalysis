Le Louvre, l'Arc de Triomphe du Carrousel by francois G.
https://3dwarehouse.sketchup.com/model/5fd46dbd26b4983fd218e3a861b121a0/Le-Louvre-lArc-de-Triomphe-du-Carrousel