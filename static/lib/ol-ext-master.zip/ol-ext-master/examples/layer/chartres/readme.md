Cathédrale Notre-Dame de Chartres by Eric D.
https://3dwarehouse.sketchup.com/model/7ea11f308949d9ae15ff6c85a773ae06/Cath%C3%A9drale-Notre-Dame-de-Chartres