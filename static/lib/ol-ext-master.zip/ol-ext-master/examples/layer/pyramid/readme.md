PIRAMIDE DE LOUVRE (incompleto) by kaligastia
https://3dwarehouse.sketchup.com/model/u098eb968-47a7-4839-a273-2184875220ee/PIRAMIDE-DE-LOUVRE-incompleto